import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-issue',
  templateUrl: './edit-issue.component.html',
  styleUrls: ['./edit-issue.component.css']
})
export class EditIssueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
