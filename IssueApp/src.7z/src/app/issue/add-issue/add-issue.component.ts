import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-issue',
  templateUrl: './add-issue.component.html',
  styleUrls: ['./add-issue.component.css']
})
export class AddIssueComponent implements OnInit {

  issue:string;
  issueType:string;
  discription:string;
  createdDate:Date;
  userid:number;
  issueStatus:number;

  constructor() { }

  onSubmit(){
    console.log(this.createdDate);
    console.log(this.issueStatus);
    
    
  }

  ngOnInit() {
  }

}
