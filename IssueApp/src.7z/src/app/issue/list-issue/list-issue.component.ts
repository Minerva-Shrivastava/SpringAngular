import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-issue',
  templateUrl: './list-issue.component.html',
  styleUrls: ['./list-issue.component.css']
})
export class ListIssueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
