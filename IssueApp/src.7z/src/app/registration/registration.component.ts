import { Component, OnInit } from '@angular/core';
import {Observable}  from 'rxjs/Observable'
import { RegisterService } from '../register.service'; 
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  firstName:string;
  lastName:string;
  email:string;
  loginName:string;
  password:string;

  constructor(private route:Router,private registerService:RegisterService) { }

  ngOnInit() {
  }
  onSubmit(){
    this.registerService.registerUser(this.firstName,this.lastName,this.email,this.loginName,this.password).subscribe(
      res =>{
        localStorage.setItem('registartionStatus','true');
        this.route.navigate(["/login"]);
      }
    )
  }
}
