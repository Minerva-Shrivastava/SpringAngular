import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  loggedIn:boolean;

  constructor(private loginService:LoginService, private router:Router) {
    if(localStorage.getItem('LoggedIn')==''|| localStorage.getItem('LoggedIn') == null) {
			this.loggedIn = true;
		} else {
			this.loggedIn=false;
		}
   }
   
   logout(){
		this.loginService.logout().subscribe(
			res => {
				localStorage.setItem('LoggedIn', '');
			},
			err => console.log(err)
			);
		location.reload();
		this.router.navigate(['/login']);
	}
  ngOnInit() {
  }

}
