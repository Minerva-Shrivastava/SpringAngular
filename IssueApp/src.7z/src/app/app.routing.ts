import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddIssueComponent } from './issue/add-issue/add-issue.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserListComponent } from './user/user-list/user-list.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { EditUserProfileComponent } from './user/edit-user-profile/edit-user-profile.component';

const appRoutes: Routes = [
  
  {
  	path: 'login',
  	component: LoginComponent
  },
  {
  	path: 'registration',
  	component: RegistrationComponent
  },
  {
    path:'dashboard',
    component: DashboardComponent
  },
  {
    path : 'addIssue',
    component: AddIssueComponent
  },
  {
    path : 'usersList',
    component : UserListComponent
  }
  ,
  {
    path : 'adminDashboard',
    component : AdminDashboardComponent
  },
  {
    path : 'editProfile',
    component: EditUserProfileComponent
  }
];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);