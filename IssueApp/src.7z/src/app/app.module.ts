import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { routing }  from './app.routing';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatButtonModule} from '@angular/material';
import {MatToolbarModule} from '@angular/material/toolbar';
import { MatFormFieldModule } from '@angular/material';
import { MatInputModule } from '@angular/material';
import { MatDatepickerModule, MatNativeDateModule } from '@angular/material';
import {MatSelectModule} from '@angular/material/select';
import { LoginComponent } from './login/login.component';
import { UserService } from './user.service';
import { LoginService } from './login.service';
import { RegisterService } from './register.service';
import { RegistrationComponent } from './registration/registration.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { NavBarComponent } from './components/nav-bar/nav-bar.component';
import { IssueService } from './issue.service';
import { EditIssueComponent } from './issue/edit-issue/edit-issue.component';
import { ListIssueComponent } from './issue/list-issue/list-issue.component';
import { AddIssueComponent } from './issue/add-issue/add-issue.component';
import { UserListComponent } from './user/user-list/user-list.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { EditUserProfileComponent } from './user/edit-user-profile/edit-user-profile.component';

 
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    DashboardComponent,
    NavBarComponent,
    EditIssueComponent,
    ListIssueComponent,
    AddIssueComponent,
    UserListComponent,
    AdminDashboardComponent,
    EditUserProfileComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatToolbarModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    routing,
    HttpModule,
    FormsModule
  ],
  providers: [
     UserService,
     LoginService,
     RegisterService,
     IssueService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
