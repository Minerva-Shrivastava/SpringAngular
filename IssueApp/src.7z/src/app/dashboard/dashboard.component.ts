import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  user:object;
  constructor(private userService:UserService, private router:Router) {
    if(localStorage.getItem('LoggedIn')==''){
      router.navigate(['/login']);
    }else{
      this.user=JSON.parse(localStorage.getItem('userLoggedIn'));
    }
   }
   
  ngOnInit() {
  }

}
