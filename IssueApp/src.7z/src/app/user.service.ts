import { Injectable } from '@angular/core';
import { Http,Response,Headers,RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { LoginService} from './login.service';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


@Injectable()
export class UserService {
  
  constructor(private http:Http, private loginService:LoginService) { }
  
  getUsers() {
    let url = "http://localhost:8080/issue-web/users/list";
    return this.http.get(url, { withCredentials: true });
  }
  changeUserStatus(userid:number){
    let url = "http://localhost:8080/issue-web/users/update";
    return this.http.put(url,{});
  }
  updateUser(firstName:string,lastName:string,email:string,id:number){
    var user={"id":id,"firstName":firstName,"lastName":lastName,"email":email }
    let url = "http://localhost:8080/issue-web/users/update";
    let headers = new Headers( { 'Content-Type': 'application/json'  });
    return this.http.put(url,user,{headers: headers, withCredentials : true})
  }
}
