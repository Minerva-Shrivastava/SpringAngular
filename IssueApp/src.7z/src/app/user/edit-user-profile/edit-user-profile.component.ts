import { Component, OnInit } from '@angular/core';
import { UserService } from '../../user.service';
import { Router } from '@angular/router'

@Component({
  selector: 'app-edit-user-profile',
  templateUrl: './edit-user-profile.component.html',
  styleUrls: ['./edit-user-profile.component.css']
})
export class EditUserProfileComponent implements OnInit {

   user:object;
   firstName:string;
   lastName:string;
   email:string;
  constructor(private userService:UserService, private router:Router) {
    if(localStorage.getItem('LoggedIn')==''){
      router.navigate(['/login']);
    }else{
      this.user=JSON.parse(localStorage.getItem('userLoggedIn'));
    }
   }

  ngOnInit() {
  }
  onSubmit(){
      this.userService.updateUser(this.firstName,this.lastName,this.email,this.user['id']).subscribe(
        res =>{
            console.log("Updated");
            
        },
        Error =>{
           console.log("Not Updated");
        }
      )
  }
}
