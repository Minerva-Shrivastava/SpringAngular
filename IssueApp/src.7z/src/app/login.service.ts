import { Injectable } from '@angular/core';
import {Http, Headers} from '@angular/http';
import {Observable}     from 'rxjs/Observable';


@Injectable()
export class LoginService {
  constructor(private http:Http) { }
  checkCredential(loginName:string,password:string){
    var user={"loginName":loginName,"password":password
    }
    let url = 'http://localhost:8080/issue-web/login';
    let params = user;
    let headers = new Headers(
    { 'Content-Type': 'application/json'
      //'Content-Type': 'application/x-www-form-urlencoded'
      // 'Access-Control-Allow-Credentials' : true
    });
    return this.http.post(url, params, {headers: headers, withCredentials : true});
  }
    logout() {
    let url = 'http://localhost:8080/issue-web/logout';
    return this.http.get(url, { withCredentials: true });
  }
}
