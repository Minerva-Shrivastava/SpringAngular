import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'; // <-- NgModel lives here
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatButtonModule, MatCheckboxModule} from '@angular/material';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatSelectModule} from '@angular/material/select';
import { HttpModule } from '@angular/http';


import { AppComponent } from './app.component';
import { AppRoutingModule } from './/app-routing.module';
import { AddQuestionComponent } from './add-question/add-question.component';

import { QuestionService } from './question.service';
import { ListQuestionComponent } from './list-question/list-question.component';


@NgModule({
  declarations: [
    AppComponent,
    AddQuestionComponent,
    ListQuestionComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    HttpModule,
    MatSelectModule

  ],
  providers: [QuestionService],
  bootstrap: [AppComponent]
})
export class AppModule { }
