import { Component, OnInit } from '@angular/core';
import { Question } from '../question';
import { QuestionService } from '../question.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-question',
  templateUrl: './list-question.component.html',
  styleUrls: ['./list-question.component.css']
})
export class ListQuestionComponent implements OnInit {

  questions : Question[];
  constructor(private router: Router, private questionService:QuestionService) { }

  ngOnInit() {
    this.getQuestions();
  }

  getQuestions() : void {
    this.questionService.getQuestionByUserId(1).subscribe(
      res => {
        this.questions=JSON.parse(JSON.parse(JSON.stringify(res))._body);
        console.log(res.text());
      }
    );
  }
}
