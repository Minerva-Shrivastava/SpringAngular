import { Injectable } from '@angular/core';
import { Headers, Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Question } from './question';
@Injectable()
export class QuestionService {

  url = 'http://localhost:8080/question_posting_web/';
  constructor(private http:Http) { }

  // getQuestions(){
  //   let url = 'http://localhost:8080/question_posting_web/questions';
  //   return this.http.get(url);
  // }

  addQuestion(question : Question){
    console.log(question);
    let url='http://localhost:8080/question_posting_web/question/'+question.userId;
    let headers = new Headers(
      {
        'Content-Type':'application/json'
      });
    return this.http.post(url, question ,{headers: headers, withCredentials:true});
  }

  
   getQuestionByUserId(id:number){
     console.log(id);
     let url='http://localhost:8080/question_posting_web/questions/'+id;
     return this.http.get(url);
   }

  
}
