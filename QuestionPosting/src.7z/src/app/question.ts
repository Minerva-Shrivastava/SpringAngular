export class Question{

    id:number;
    userId:number;
    catogoryId:number;
    question:string;
    status:number;

}