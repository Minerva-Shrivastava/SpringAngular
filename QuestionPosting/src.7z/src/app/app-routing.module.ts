import { NgModule } from '@angular/core';
import  { AddQuestionComponent } from './add-question/add-question.component';
import { ListQuestionComponent } from './list-question/list-question.component'; 

import { Routes, RouterModule } from '@angular/router';

const appRoutes: Routes = [
  
  {
  	path: 'question',
  	component: AddQuestionComponent
  },
  {
  	path: 'listQuestion',
  	component: AddQuestionComponent
  }
];
@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    RouterModule
  ],
})
export class AppRoutingModule { }
