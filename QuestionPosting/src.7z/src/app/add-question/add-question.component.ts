import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Question } from '../question';
import { QuestionService } from '../question.service';

@Component({
  selector: 'app-add-question',
  templateUrl: './add-question.component.html',
  styleUrls: ['./add-question.component.css']
})
export class AddQuestionComponent implements OnInit {

  questionAsked : string;
  categorySelected : string;
  categorySelectedId : number;
  textValue = 'initial value';
  question : Question = new Question(); 
  list: any = [
    {id: 1, name: 'Java'},
    {id: 2, name: 'Spring'},
    {id: 3, name: 'Hibernate'}
  ];
  
  log = '';

  logText(value: string): void {
    
    this.log += `Text changed to '${value}'\n`;
  }

  logDropdown(id: number): void {
    this.categorySelectedId = id;
    this.categorySelected = this.list.find((item: any) => item.id === +id).name;
    this.log += `Value ${this.categorySelected} was selected\n`;
    
  }
  
  constructor(private router: Router, private questionService:QuestionService) { }

  ngOnInit() {
    this.question.userId = 1;
    this.question.catogoryId = 1;
    this.question.status = 1;
  }

 addQuestion(value: string){
  this.questionAsked = `${value}`;
  console.log(this.questionAsked);
  this.question.question = this.questionAsked;
  this.question.catogoryId = this.categorySelectedId;

   this.questionService.addQuestion(this.question).subscribe(
     res=>{
         console.log(res);
       },
       err=>{
         console.log(err);
       }
     );
   }
}
