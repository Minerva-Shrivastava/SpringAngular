package com.yash.question_posting_core.dao;

import java.util.List;

import com.yash.question_posting_core.model.Question;

/**
 * This interface specifies the operations to be 
 * performed related to Question entity
 * @author minerva.shrivastava
 *
 */
public interface QuestionDAO {

	/**
	 * This method inserts the question
	 * @param question
	 * @return true if question is inserted
	 */
	public boolean insert(Question question);
	
	
	/**
	 * This method retrieves the list of all Questions
	 * @param id of the user whose questions are to retrieved
	 * @return List of Questions posted by a particular user
	 */
	public List<Question> listAllQuestions(int id);
	
}
