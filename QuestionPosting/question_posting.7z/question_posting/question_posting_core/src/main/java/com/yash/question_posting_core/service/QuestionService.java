package com.yash.question_posting_core.service;

import java.util.List;

import com.yash.question_posting_core.model.Question;

/**
 * This service will handle Question related services
 * @author minerva.shrivastava
 *
 */
public interface QuestionService {

	/**
	 * This method provides the service of inserting the question
	 * @param question which is to be inserted
	 * @return true if question is inserted
	 */
	public boolean addQuestion(Question question);
	
	/**
	 * This method retrieves the list of all Questions
	 * @param id of user whose questions are to retrieved
	 * @return List of Questions posted by a particular user
	 */
	public List<Question> listAllQuestions(int id);
}
