package com.yash.question_posting_core.daoimpl;

import java.util.LinkedList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.yash.question_posting_core.dao.QuestionDAO;
import com.yash.question_posting_core.model.Question;

/**
 * This class is the implementation of QuestionDAO
 * @author minerva.shrivastava
 *
 */
@Repository
public class QuestionDAOImpl implements QuestionDAO{

	/**
	 * The session factory variable which is autowired
	 */
	@Autowired
	private SessionFactory sessionFactory;
	
	/**
	 * session will be obtained from session factory
	 */
	private Session session;
	
	/**
	 * This method inserts the Question into the database through the hibernate 
	 * saveOrUpdate method in a transaction which is relledback in case of an exception  
	 */
	public boolean insert(Question question) {
		session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.getTransaction();
			transaction.begin();
			session.saveOrUpdate(question);
			transaction.commit();
			return true;
		} catch (HibernateException ex) {
			if (transaction != null) {
				System.out.println("Rollback the transaction");
				transaction.rollback();
			}
			ex.printStackTrace();
			return false;
		} finally {
			session.close();
		}
	}

	/**
	 * This method retrieves the Questions list from the database 
	 */
	public List<Question> listAllQuestions(int id) {
		
		List<Question> questions = new LinkedList<Question>();
		
		Session session = sessionFactory.openSession();
		System.out.println("session :"+session);

		Transaction transaction = null;

		try {
			
			transaction = session.getTransaction();
			transaction.begin();
			Query query = session.createQuery("from Question q where q.id=:id");
			query.setParameter("id", id);
			questions = query.list();
			
			for (Question question : questions) {
				System.out.println(question.getQuestion());
			}
			
			transaction.commit();

		}catch (HibernateException ex) {

			if (transaction != null) {
				transaction.rollback();
			}
			ex.printStackTrace();

		} finally {
			session.close();
		}
		
		return questions;
	}

}
