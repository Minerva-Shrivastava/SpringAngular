package com.yash.question_posting_core.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class represents the model object, the entity question.
 * This class is used as a data traveler
 * It contains id, userId, categoryId, question and status 
 * @author minerva.shrivastava
 *
 */

@Entity
@Table(name="questions")
public class Question {

	/** id of question */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	/** id of user who is posting the question */
	private Integer userId;
	
	/** id of category in which the question belongs */
	private Integer categoryId;
	
	/** The detailed question */
	private String question;
	
	/** status of question can approved(available for other members) 
	 * or not approved(not available to other members) */
	private Integer status;
	
	
	/** default constructor*/
	public Question() {
		super();
	}

	/** parametrized constructor*/
	public Question(Integer id, Integer userId, Integer categoryId, String question, Integer status) {
		super();
		this.id = id;
		this.userId = userId;
		this.categoryId = categoryId;
		this.question = question;
		this.status = status;
	}
	
	/** Getter and setters */
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Integer getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	
	
	
}
