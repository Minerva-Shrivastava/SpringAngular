package com.yash.question_posting_core.serviceimpl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yash.question_posting_core.dao.QuestionDAO;
import com.yash.question_posting_core.model.Question;
import com.yash.question_posting_core.service.QuestionService;

/**
 * This class is the implementation of the QuestionService interface 
 * providing service's implementation related to Question
 * @author minerva.shrivastava
 *
 */
@Service
public class QuestionServiceImpl implements QuestionService{

	
	/**
	 * The services call the DAO layer functionalities through this variable
	 */
	@Autowired
	private QuestionDAO questionDAO;
	
	/**
	 * This method calls the DAO to insert the Question 
	 */
	public boolean addQuestion(Question question) {
		return questionDAO.insert(question);
	}

	/**
	 * This method calls the DAO to get the list of all Questions
	 */
	public List<Question> listAllQuestions(int id) {
		return questionDAO.listAllQuestions(id);
	}

}
