package com.yash.question_posting_web.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.yash.question_posting_core.configuration.ApplicationDBConfig;

/**
 * Configuration for web components and for enabling annotations
 * extends ApplicationDBConfig of core module for core configurations
 * @author minerva.shrivastava
 *
 */
@Configuration
@EnableWebMvc
@ComponentScan("com.yash")
public class QuestionPostingWebConfiguration extends WebMvcConfigurerAdapter {

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/demoweb/**")
			.allowedOrigins("http://localhost:4200")
			.allowedMethods("POST", "PUT", "GET", "OPTIONS", "DELETE")
			.allowedHeaders("x-requested-with")
			.maxAge(3600);
	}
}
