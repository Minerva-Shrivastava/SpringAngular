package com.yash.question_posting_web.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.yash.question_posting_core.model.Question;
import com.yash.question_posting_core.service.QuestionService;

/**
 * This controller will perform all the Question related controlling
 * @author minerva.shrivastava
 *
 */
@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600, 
		allowedHeaders="x-requested-with")
@RestController
@RequestMapping("/")
public class QuestionController {

	/**
	 * The question services are autowired from the core module
	 */
	@Autowired
	private QuestionService questionService;
	
	
	/**
	 * The controller method to add the questions 
	 * @param question obtained from the body of the request
	 */
	@RequestMapping(value="/question", method=RequestMethod.POST)
	public String addQuestions(@RequestBody Question question){
		 boolean result = questionService.addQuestion(question);
		 if(result)
			 return "Question added successfully";
		 else
			 return "error";
	}
	
	/**
	 * This controller method retrieves the list of all Question posted by a particular user
	 * @param id of user whose Questions are to be retrieved
	 * @return List of Questions of that paricular user
	 */
	@RequestMapping(value="/questions/{id}", method=RequestMethod.GET)
	public List<Question> getAllQuestions(@PathVariable Integer id){
		return questionService.listAllQuestions(id);
		
	}
	
}
